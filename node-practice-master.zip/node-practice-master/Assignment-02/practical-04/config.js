//mongoose config
module.exports = {
    database: 'mongodb://localhost:27017/studentdb',
    secret: 'yoursecret'
}