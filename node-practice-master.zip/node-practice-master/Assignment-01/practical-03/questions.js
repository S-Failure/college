exports.questionlist = [{
    question: "What is the name of the main character in the game?",
    answer: "Mario"
},{
    question: "How many lives does Mario have?",
    answer: "3"
},{
    question: "Who is the main villain in the game?",
    answer: "Bowser"
},{
    question: "What is the name of the game's main theme?",
    answer: "Super Mario"
},{
    question: "How many coins does Mario have?",
    answer: "0"
}];