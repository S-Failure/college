
/**
 * Restful services here
 */
package com.muzammilnagariya.msasecondclient.service;