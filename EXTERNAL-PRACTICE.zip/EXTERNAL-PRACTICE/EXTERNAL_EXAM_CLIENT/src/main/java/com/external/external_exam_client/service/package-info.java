
/**
 * Restful services here
 */
package com.external.external_exam_client.service;