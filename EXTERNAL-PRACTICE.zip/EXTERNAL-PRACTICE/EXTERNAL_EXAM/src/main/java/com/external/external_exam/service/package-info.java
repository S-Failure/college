
/**
 * Restful services here
 */
package com.external.external_exam.service;