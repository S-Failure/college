
/**
 * Restful services here
 */
package com.muzammilnagariya.msasecondapp.service;